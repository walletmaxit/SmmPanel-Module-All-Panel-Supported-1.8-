            <!--file location: app/controller/addfunds.php-->  

             if(isset($_GET['success'])){
                  $DB_HOST = 'localhost';
                  $DB_USER = '';
                  $DB_PASS = '';
                  $DB_NAME = '';
                  
                  $url = constant("URL");
                  
                  $sqlconn=mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);
                  
                  $user_idssss = $user['email'];
                  
                  $amount_session = $_GET['success'];
                  
                    $transactionId = $_GET['transactionId'];
                    $paymentAmount = $_GET['paymentAmount'];
                    $paymentFee = $_GET['paymentFee'];

                    $transaction_id_walletmaxpay = $transactionId;

                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => 'https://pay.walletmaxpay.com/verify.php',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => array('transaction_id' => $transaction_id_walletmaxpay),
                    ));
                    $response = curl_exec($curl);
                    curl_close($curl);
                    
                    if($response == 1){
                          $date_doka = date("Y.m.d H:i:s");
                          $client_ids = $user['client_id'];
                          $get_id = GetIP();
                          
                          $insert_history = "INSERT INTO payments (client_id,payment_amount,payment_privatecode,payment_method,payment_mode,payment_create_date,payment_ip,payment_extra,payment_status) VALUES ('$client_ids','$amount_session','0','18','Otomatik','$date_doka','$get_id','Check walletmaxpay','3')";
                          mysqli_query($sqlconn,$insert_history);
                          
                          $sql = "UPDATE clients SET `balance`=`balance`+$amount_session WHERE email='$user_idssss'";
                          if(mysqli_query($sqlconn,$sql)){
            ?>
                            <script>
                                location.href="<?php echo $url?>/addfunds";
                            </script>
            <?php
                          }
                    }else{
                         echo "Failed. Id Not Match";
                    }
             }

            

            //past in body
            elseif ($method_id == 18):
            
            $start_amount = $extra['currency_rate']*$amount;
            $total_amount = $start_amount;
            
            $total_amount = number_format((float) $total_amount, 2, ".", "");

            $amounts = $total_amount;

            $apikey = $extra['api_key']; //Your Api Key
            $clientkey = $extra['client_key']; //Your Client Key
            $secretkey = $extra['secret_key']; //Your Secret Key

            $cus_name = $user['first_name'];
            $cus_email = $user['email'];

            //success url
            $success_url = site_url('addfunds?success=').$amount;
            //cancel url
            $cancel_url = site_url('addfunds?canncel=true');
            $hostname = $extra['host_name'];
                        
            echo '<div class="dimmer active" style="min-height: 400px;">
                <div class="loader"></div>
                <div class="dimmer-content">
                    <center>
                        <h2>Loading...</h2>
                    </center>
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin:auto;background:#fff;display:block;" width="200px" height="200px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                        <circle cx="50" cy="50" r="32" stroke-width="8" stroke="#e15b64" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round">
                            <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
                        </circle>
                        <circle cx="50" cy="50" r="23" stroke-width="8" stroke="#f8b26a" stroke-dasharray="36.12831551628262 36.12831551628262" stroke-dashoffset="36.12831551628262" fill="none" stroke-linecap="round">
                            <animateTransform attributeName="transform" type="rotate" dur="1s" repeatCount="indefinite" keyTimes="0;1" values="0 50 50;-360 50 50"></animateTransform>
                        </circle>
                    </svg>
                    <form action="https://pay2.walletmaxpay.com/checkout.php" method="POST" id="walletmaxpays">
                        <input type="hidden" name="api"value="'.$apikey.'">
                        <input type="hidden" name="client"value="'.$clientkey.'">
                        <input type="hidden" name="secret"value="'.$secretkey.'">
                        <input type="hidden" name="amount"value="'.$amounts.'">
                        <input type="hidden" name="position"value="'.$hostname.'">
                        <input type="hidden" name="success_url"value="'.$success_url.'">
                        <input type="hidden" name="cancel_url"value="'.$cancel_url.'">
                        <input type="hidden" name="cus_name"value="'.$cus_name.'">
                        <input type="hidden" name="cus_email"value="'.$cus_email.'">

                        <script type="text/javascript">
                            document.getElementById("walletmaxpays").submit();
                        </script>
                    </form>
                </div>
            </div>';